
package scalation

/** The activity package contains classes, traits and objects for
 *  activity-oriented simulation models (for example, Petri Nets).
 */
package object activity { } 

