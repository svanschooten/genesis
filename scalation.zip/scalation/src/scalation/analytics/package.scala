
package scalation

/** The analytics package contains classes, traits and objects for
 *  analytics including classification, clustering and prediction.
 */
package object analytics { } 

