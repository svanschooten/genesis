
package scalation

/** The animation package contains classes, traits and objects for
 *  2D animation of simulation objects.
 */
package object animation { } 

