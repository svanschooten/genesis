
package scalation

/** The calculus package contains a class with methods
 *  for computing derivatives, gradients and Jacobians.
 */
package object calculus { } 

