
package scalation

/** The dynamics package contains classes, traits and objects for
 *  system dynamics simulations using Ordinary Differential Equations (ODEs).
 */
package object dynamics { } 

