
package scalation

/** The event package contains classes, traits and objects for event-oriented
 *  simulation models (for example, event-scheduling or event-graphs).
 */
package object event { } 

