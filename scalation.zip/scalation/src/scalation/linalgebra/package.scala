
package scalation

/** The linalgebra package contains classes, traits and objects for
 *  linear algebra, including vectors and matrices for real and complex numbers.
 */
package object linalgebra { } 

