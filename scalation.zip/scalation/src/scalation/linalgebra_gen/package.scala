
package scalation

/** The linalgebra_gen package contains generic classes, traits and objects for
 *  linear algebra, including vectors and matrices for types implementing Numeric.
 */
package object linalgebra_gen { } 

