
package scalation

/** The math package contains classes, traits and objects for
 *  common mathematical operations.
 */
package object math { } 

