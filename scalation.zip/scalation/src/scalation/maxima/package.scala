
package scalation

/** The maxima package contains classes, traits and objects for
 *  optimization to find maxima.
 */
package object maxima { } 

