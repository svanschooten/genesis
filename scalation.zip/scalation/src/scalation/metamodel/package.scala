
package scalation

/** The metamodel package contains classes, traits and objects for
 *  meta-modeling in simulation that is used to produce responses without
 *  running the full detailed model.
 */
package object metamodel { } 

