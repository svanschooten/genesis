
package scalation

/** The minima package contains classes, traits and objects for
 *  optimization to find minima.
 */
package object minima { } 

