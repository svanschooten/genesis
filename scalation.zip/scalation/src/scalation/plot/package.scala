
package scalation

/** The plot package contains classes, traits and objects for
 *  simple plotting of x-y data.
 */
package object plot { } 

