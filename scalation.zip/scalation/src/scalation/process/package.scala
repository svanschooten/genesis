
package scalation

/** The process package contains classes, traits and objects for process-oriented
 *  simulation models (for example, process-interaction).
 */
package object process { } 

