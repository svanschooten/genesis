
package scalation

/** The queueingnet package contains classes, traits and objects for
 *  solving simple queueing network problems.
 */
package object queueingnet { } 

