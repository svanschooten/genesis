
package scalation

/** The random package contains classes, traits and objects for
 *  the generation of random numbers.
 */
package object random { } 

