
package scalation

/** The scala2d package contains classes, traits and objects for
 *  for simple 2D graphics in scala, based upon java_swing, java_awt and
 *  java_awt_geom.
 */
package object scala2d { } 

