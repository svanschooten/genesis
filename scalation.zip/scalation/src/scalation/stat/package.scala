
package scalation

/** The stat package contains classes, traits and objects for
 *  basic statistical functions and analyses.
 */
package object stat { } 

