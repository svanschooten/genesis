
package scalation

/** The state package contains classes, traits and objects for
 *  state-oriented simulation models (for example, Markov Chains).
 */
package object state { } 

