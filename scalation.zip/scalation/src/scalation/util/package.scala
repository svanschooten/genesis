
package scalation

/** The util package contains classes, traits and objects for
 *  basic utility functions.
 */
package object util { } 

